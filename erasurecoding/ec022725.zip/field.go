package erasurecoding

import (
	"fmt"
	"sync"
)

var (
	precomputeOnce         sync.Once
	precomputedDataShardXs []GFPoint
	precomputedValidatorXs []GFPoint
	generatorMatrix        [][]GFPoint
	genMatOnce             sync.Once
)

// precomputeXs will precompute the evaluation points (using GFPoint(i+1)) and the generator matrix
func precomputeXs() {
	ensureGFTables()
	K, N := GetCodingRate()
	precomputedDataShardXs = make([]GFPoint, K)
	for i := 0; i < K; i++ {
		precomputedDataShardXs[i] = GFPoint(i + 1)
	}
	precomputedValidatorXs = make([]GFPoint, N)
	for i := 0; i < N; i++ {
		precomputedValidatorXs[i] = GFPoint(i + 1)
	}
	computeGeneratorMatrix()
}

func computeGeneratorMatrix() {
	genMatOnce.Do(func() {
		K, N := GetCodingRate()
		V := make([][]GFPoint, N)
		for i := 0; i < N; i++ {
			V[i] = make([]GFPoint, K)
			v := precomputedValidatorXs[i]
			power := GFPoint(1)
			for j := 0; j < K; j++ {
				V[i][j] = power
				power = Mul(power, v)
			}
		}

		// Vdata is the first K rows of V (corresponding to the evaluation points of data shards)
		Vdata := make([][]GFPoint, K)
		for i := 0; i < K; i++ {
			Vdata[i] = make([]GFPoint, K)
			copy(Vdata[i], V[i])
		}
		invVdata, err := invertMatrixGF(Vdata)
		if err != nil {
			panic(err)
		}
		generatorMatrix = make([][]GFPoint, N)
		for i := 0; i < N; i++ {
			generatorMatrix[i] = make([]GFPoint, K)
			for j := 0; j < K; j++ {
				var sum GFPoint = 0
				for k := 0; k < K; k++ {
					sum = Add(sum, Mul(V[i][k], invVdata[k][j]))
				}
				generatorMatrix[i][j] = sum
			}
		}
	})
}

func invertMatrixGF(mat [][]GFPoint) ([][]GFPoint, error) {
	n := len(mat)
	aug := make([][]GFPoint, n)
	for i := 0; i < n; i++ {
		aug[i] = make([]GFPoint, 2*n)
		for j := 0; j < n; j++ {
			aug[i][j] = mat[i][j]
		}
		for j := n; j < 2*n; j++ {
			if j-n == i {
				aug[i][j] = 1
			} else {
				aug[i][j] = 0
			}
		}
	}
	for i := 0; i < n; i++ {
		if aug[i][i] == 0 {
			found := false
			for j := i + 1; j < n; j++ {
				if aug[j][i] != 0 {
					aug[i], aug[j] = aug[j], aug[i]
					found = true
					break
				}
			}
			if !found {
				return nil, fmt.Errorf("singular matrix")
			}
		}
		invPivot := Inv(aug[i][i])
		for j := i; j < 2*n; j++ {
			aug[i][j] = Mul(aug[i][j], invPivot)
		}
		for k := 0; k < n; k++ {
			if k == i {
				continue
			}
			factor := aug[k][i]
			for j := i; j < 2*n; j++ {
				aug[k][j] = Add(aug[k][j], Mul(factor, aug[i][j]))
			}
		}
	}
	invMat := make([][]GFPoint, n)
	for i := 0; i < n; i++ {
		invMat[i] = make([]GFPoint, n)
		for j := 0; j < n; j++ {
			invMat[i][j] = aug[i][j+n]
		}
	}
	return invMat, nil
}
