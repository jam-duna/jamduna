// erasurecoding.go
package erasurecoding

import (
	"fmt"
	"sync"

	"github.com/colorfulnotion/jam/types"
)

func GetCodingRate() (int, int) {
	K := types.W_E / 2
	N := types.TotalValidators
	return K, N
}

// Encode will return an error if the input data is empty.
func Encode(data []byte, shardPieces int) ([][][]byte, error) {
	precomputeOnce.Do(precomputeXs)
	K, N := GetCodingRate()
	shardSize := shardPieces * 2
	pointsPerGroup := K * shardPieces

	totalPoints := (len(data) + 1) / 2
	allPoints := make([]GFPoint, totalPoints)
	for i := 0; i < totalPoints; i++ {
		index := 2 * i
		var b0, b1 byte
		b0 = data[index]
		if index+1 < len(data) {
			b1 = data[index+1]
		} else {
			b1 = 0
		}
		// Reconstructing the original data is done in the same way
		allPoints[i] = GFPoint(uint16(b1)<<8 | uint16(b0))
	}

	numGroups := (len(allPoints) + pointsPerGroup - 1) / pointsPerGroup
	out := make([][][]byte, numGroups)
	var wg sync.WaitGroup
	for g := 0; g < numGroups; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			groupPoints := make([]GFPoint, pointsPerGroup)
			start := g * pointsPerGroup
			end := start + pointsPerGroup
			for i := start; i < end; i++ {
				if i < len(allPoints) {
					groupPoints[i-start] = allPoints[i]
				} else {
					groupPoints[i-start] = 0
				}
			}
			groupShards := make([][]byte, N)
			for s := 0; s < N; s++ {
				groupShards[s] = make([]byte, shardSize)
			}
			var wgRow sync.WaitGroup
			for row := 0; row < shardPieces; row++ {
				wgRow.Add(1)
				go func(row int) {
					defer wgRow.Done()
					rowStart := row * K
					coeff := make([]GFPoint, K)
					copy(coeff, groupPoints[rowStart:rowStart+K])
					for s := 0; s < N; s++ {
						var code GFPoint = 0
						for j := 0; j < K; j++ {
							code = Add(code, Mul(generatorMatrix[s][j], coeff[j]))
						}
						groupShards[s][row*2] = byte(code & 0xFF)
						groupShards[s][row*2+1] = byte((code >> 8) & 0xFF)
					}
				}(row)
			}
			wgRow.Wait()
			out[g] = groupShards
		}(g)
	}
	wg.Wait()
	return out, nil
}

// Decode will return an error if there are not enough shards to recover the data.
func Decode(data [][][]byte, shardPieces int) ([]byte, error) {
	precomputeOnce.Do(precomputeXs)
	K, _ := GetCodingRate()
	shardSize := shardPieces * 2
	groupDataSize := K * shardSize

	result := make([]byte, len(data)*groupDataSize)
	var wg sync.WaitGroup
	var decodeErr error
	var errMutex sync.Mutex

	for g := 0; g < len(data); g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			groupShards := data[g]
			if len(groupShards) == 0 {
				return
			}
			recovered := make([]byte, groupDataSize)
			for row := 0; row < shardPieces; row++ {
				type avail struct {
					Code  GFPoint
					Index int
				}
				var available []avail
				for idx, shard := range groupShards {
					if shard == nil || len(shard) < (row+1)*2 {
						continue
					}
					low := shard[row*2]
					high := shard[row*2+1]
					val := GFPoint(uint16(high)<<8 | uint16(low))
					available = append(available, avail{Code: val, Index: idx})
				}
				if len(available) < K {
					errMutex.Lock()
					decodeErr = fmt.Errorf("group %d, row %d: not enough shards", g, row)
					errMutex.Unlock()
					return
				}
				H := make([][]GFPoint, K)
				y := make([]GFPoint, K)
				for i := 0; i < K; i++ {
					idx := available[i].Index
					H[i] = make([]GFPoint, K)
					copy(H[i], generatorMatrix[idx])
					y[i] = available[i].Code
				}
				invH, err := invertMatrixGF(H)
				if err != nil {
					errMutex.Lock()
					decodeErr = fmt.Errorf("group %d, row %d: %v", g, row, err)
					errMutex.Unlock()
					return
				}
				coeff := make([]GFPoint, K)
				for i := 0; i < K; i++ {
					var sum GFPoint = 0
					for j := 0; j < K; j++ {
						sum = Add(sum, Mul(invH[i][j], y[j]))
					}
					coeff[i] = sum
				}
				for i := 0; i < K; i++ {
					recovered[2*(row*K+i)] = byte(coeff[i] & 0xFF)
					recovered[2*(row*K+i)+1] = byte((coeff[i] >> 8) & 0xFF)
				}
			}
			copy(result[g*groupDataSize:(g+1)*groupDataSize], recovered)
		}(g)
	}
	wg.Wait()
	if decodeErr != nil {
		return nil, decodeErr
	}
	return result, nil
}
