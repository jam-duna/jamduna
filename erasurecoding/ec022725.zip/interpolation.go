package erasurecoding

import "sync"

type GFPoint uint16

const (
	irreduciblePoly = 0x1002D
	fieldSize       = 1 << 16 // 65536
	fieldOrder      = fieldSize - 1
)

var (
	gfExp        [fieldSize * 2]GFPoint
	gfLog        [fieldSize]int
	gfTablesOnce sync.Once
)

func ensureGFTables() {
	gfTablesOnce.Do(initGFTables)
}

func initGFTables() {
	gfExp[0] = 1
	var generator GFPoint = 2
	gfLog[0] = -1
	for i := 1; i < fieldOrder; i++ {
		gfExp[i] = mulBasic(gfExp[i-1], generator)
		if gfExp[i] != 0 {
			gfLog[gfExp[i]] = i
		}
	}
	for i := fieldOrder; i < len(gfExp); i++ {
		gfExp[i] = gfExp[i-fieldOrder]
	}
}

func mulBasic(a, b GFPoint) GFPoint {
	var result uint32
	aa := uint32(a)
	bb := uint32(b)
	for i := 0; i < 16; i++ {
		if bb&1 != 0 {
			result ^= aa
		}
		bb >>= 1
		aa <<= 1
		if aa&0x10000 != 0 {
			aa ^= uint32(irreduciblePoly)
		}
	}
	return GFPoint(result & 0xFFFF)
}

// Add computes the sum of a and b in GF(2^16)
func Add(a, b GFPoint) GFPoint {
	return a ^ b
}

// Mul computes the product of a and b in GF(2^16)
func Mul(a, b GFPoint) GFPoint {
	ensureGFTables()
	if a == 0 || b == 0 {
		return 0
	}
	sum := gfLog[a] + gfLog[b]
	if sum >= fieldOrder {
		sum -= fieldOrder
	}
	return gfExp[sum]
}

// Inv computes the multiplicative inverse of a (a ≠ 0)
func Inv(a GFPoint) GFPoint {
	ensureGFTables()
	if a == 0 {
		panic("inverse of zero")
	}
	return gfExp[fieldOrder-gfLog[a]]
}

// EvaluatePoly uses Horner's method to evaluate the value of polynomial p at x
func EvaluatePoly(p []GFPoint, x GFPoint) GFPoint {
	var result GFPoint = 0
	power := GFPoint(1)
	for _, coeff := range p {
		result = Add(result, Mul(coeff, power))
		power = Mul(power, x)
	}
	return result
}
